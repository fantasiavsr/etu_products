<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main">

        
        <div class="px-4 py-5" style="background-color: #EDEFF5">
            <br>

            <div class="container pt-2 pb-5 text-center justify-content-center px-5">

                <div class="row justify-content-center text-center">
                    <h2 class="fw-bold">Produk Kami</h2>
                </div>

                <div class="row row-cols-1 row-cols-md-3 g-3 pt-5">

                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col d-flex">
                            <div class="card mb-3 shadow-sm pb-3" style="max-width: 100%;">
                                <div class="row g-0">

                                    <img src="<?php echo e(asset('image/' . $data->gambar)); ?>" class="card-img-top" alt=""
                                        style="width: 100%;
                                    height: 20vw;
                                    object-fit: cover;">

                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($data->nama); ?></h5>
                                        <p class="card-text"><?php echo e($data->desk); ?></p>
                                        <a href="<?php echo e(route('detail_produk', ['id' => $data->id])); ?>" class="btn rounded-pill me-4 btn-outline-dark px-4 mt-4">Detail
                                        </a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <div class="row justify-content-center text-center pt-5">
                    <h2 class="fw-bold">Alumni PMW</h2>
                </div>

                <div class="row row-cols-1 row-cols-md-3 g-3 pt-5">

                    <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col d-flex">
                            <div class="card mb-3 shadow-sm pb-3" style="max-width: 100%;">
                                <div class="row g-0">

                                    <img src="<?php echo e(asset('image/' . $data->gambar)); ?>" class="card-img-top" alt=""
                                        style="width: 100%;
                                    height: 20vw;
                                    object-fit: cover;">

                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($data->nama); ?></h5>
                                        <p class="card-text"><?php echo e($data->desk); ?></p>
                                        <a href="<?php echo e('/alumni'.$data->id); ?>" class="btn rounded-pill me-4 btn-outline-dark px-4 mt-4">Detail
                                        </a>
                                    </div>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                

            </div>


        </div>

    </div>

    <?php echo $__env->make('Partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\etu_products\resources\views/list_products.blade.php ENDPATH**/ ?>