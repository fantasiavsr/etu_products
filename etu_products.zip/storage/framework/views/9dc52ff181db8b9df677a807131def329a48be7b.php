<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('Partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="main">

        
        <div class="text-secondary px-4 pt-2 pb-2" style="background-color: #3a51a3;">

            <div class="container px-1">
                <div class="row align-items-center">
                    <div class="col-lg-6 d-flex gap-3">
                        <img class="avatar rounded-circle mb-4 mt-5" src="<?php echo e(asset('image/' . $data->logo)); ?>" alt=""
                            style="width:60x; height:60px">
                        <h1 class="display-5 fw-bold text-white mb-4 mt-5"><?php echo e($data->nama); ?></h1>
                    </div>
                    <div class="col">
                        <div class="float-end">
                            <a href="<?php echo e($data->sosmed); ?>" target="_blank">
                                <button type="button"
                                    class="btn btn-lg rounded-pill btn-outline-light px-4 me-sm-3 mb-4 mt-5">
                                    Kunjungi Sosmed/Toko
                                </button>
                            </a>
                            
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="px-2 py-3">

            
            <div class="container">

                <div class="text-center align-items-center mb-3 pb-2">
                    <div class="row g-0 text-center align-items-center">
                        <img src="<?php echo e(asset('image/' . $data->gambar)); ?>"
                            class="img-responsive text-center align-items-center" alt=""
                            style="width: 100%;
                            height: 20vw;
                            object-fit: cover;">
                    </div>
                </div>

                <div class="text-center align-items-center mb-3 pb-2">
                    <div class="row g-0 text-center align-items-center">
                        <img src="<?php echo e(asset('image/pdx16-1.jpeg')); ?>"
                            class="img-responsive text-center align-items-center" alt=""
                            style="width: 100%;
                            height: 70vw;
                            object-fit: cover;">
                    </div>
                </div>

                <div class="text-center align-items-center mb-3 pb-2">
                    <div class="row g-0 text-center align-items-center">
                        <img src="<?php echo e(asset('image/pdx16-2.jpeg')); ?>"
                            class="img-responsive text-center align-items-center" alt=""
                            style="width: 100%;
                            height: 70vw;
                            object-fit: cover;">
                    </div>
                </div>

            </div>

        </div>

        <?php echo $__env->make('Partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\etu_products\resources\views/alumni/alumni4.blade.php ENDPATH**/ ?>