<ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar" {{-- style="background-color: #4FBEAB" --}}>
    <!-- Sidebar - Brand -->
    <{{-- a class="sidebar-brand d-flex align-items-center justify-content-center" href="{{ 'user' }}">
        <div class="sidebar-brand-icon pt-3">
            <img class="img" src="{{ asset('img/gv-text-dark.png') }}" alt="" style="width: 83%">
        </div>
    </a> --}} <!-- Divider -->
        <hr class="sidebar-divider my-2">

        <!-- Nav Item - Dashboard -->
        <li class="nav-item">
            <a class="nav-link" href=""
                style="color: #4FBEAB; background-color:#F9FAFC;  border-right: 8px solid #4FBEAB;">
                <i class="fas fa-fw fa-home"></i>
                <span>Dashboard</span></a>
        </li>

</ul>
